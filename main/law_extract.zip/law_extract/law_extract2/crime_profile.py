# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time
from collections import defaultdict,Counter
import pandas as pd

count = Counter()

def count_item(count,items):
    #items is a string in a certain row
    if not isinstance(items,float):
        items = str(items)
        item_per_row = items.split('||')
        #print item_per_row
        for ii in item_per_row:
            count[ii.decode('utf8')] +=1
        #print count
        return count

def del_null_key(count):
    #implement this function after itered all the rows and done the count
    x_t ={}
    for i,v in enumerate(count.keys()):
        if len(v)>0:
            index = v
            value = count[v]
            i_c[index] = value
    return x_t

def get_all_keys(count_list):
    key_list =[]
    for cc in count_list:
        cc_key = cc.keys()
        key_list.extend(cc_key)

    all_key_list = list(set(key_list))

    return all_key_list



def save_df(df,row_i,key,reason_crime_dic,col_name):


    #count_dict = count[count.keys()[row_i]]
    df.loc[row_i,'crime_reason'] = key
    for idx,cl in enumerate(col_name):
        df.loc[row_i,cl] =str(reason_crime_dic[idx][key])
    return df




def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1876058#2824916
    reason_gender_dic = defaultdict(Counter)
    #reason_dic = {}
    reason_nation_dic = defaultdict(Counter)
    reason_edu_dic = defaultdict(Counter)
    reason_spt_num_dic = defaultdict(Counter)
    #count1 = Counter()

    #count2 = Counter()
    for start in range(40,43,batch_amount):
        count_g = Counter()

        count_n = Counter()
        count_e = Counter()
        #count_s = Counter()
        if start % 1000 == 0:
            print start
            #time.sleep(1)
        # sql = "SELECT uuid,id,party_info FROM judgment WHERE id >= %d LIMIT %d "  %(start,batch_amount)
        sql = "SELECT id,gender,reason,nation,edu FROM tmp_hzj WHERE id = %d "  % start
        #print sql
        cur.execute(sql)
        #print cur.description
        #print 'cur is',cur

        #print '####'
        for row in cur:
            gender =  row[1]

            #print gender #unicode
            reason = row[2]
            #print reason
            #print reason
            reason = reason.split('||')
            nation = row[3]
            edu = row[4]
            #ssp_num = row[5]
            #print gender
            #print nation
            #print edu


            for rr in reason:




                vals_g = count_item(count_g,gender)
                vals_n = count_item(count_n,nation)
                vals_e = count_item(count_e, edu)
                #vals_s = count_item(count_s, ssp_num)
                reason_gender_dic[rr].update(vals_g)
                reason_nation_dic[rr].update(vals_n)
                reason_edu_dic[rr].update(vals_e)
                # if not reason_gender_dic.get(rr):
                #     reason_gender_dic[rr] = vals1
                # else:
                #
                #
                #     reason_gender_dic.update({rr:vals1})






                #nation_count = count_item(nation)
                #reason_gender[rr].update(vals1)
            #for rr2 in reason:

                #key = rr2
                #vals2 = count_item(count2,nation)
                #reason_gender_dic[rr].update(vals1)
                #reason_gender[rr].update(vals2)
    return reason_gender_dic,reason_nation_dic,reason_edu_dic

#this version doesn't work, seems run the gender, nation ,edu,speately will be a good idea beacause it is more robust
if __name__ =='__main__':
    reason_g,reason_n,reason_e = art_select()
    all_key_list = get_all_keys([reason_g,reason_n,reason_e])
    test_new_df = pd.DataFrame()
    for nn,key in enumerate(all_key_list):
        test_new_df = save_df(test_new_df,nn,key,[reason_g,reason_n,reason_e],['gender','nation','edu'])
    save_path = '/home/sherlock/withcopu_dic/law_extract/law_extract2/test_multi_col_reason817.csv'
    test_new_df.to_csv(save_path,header=True,index=False,encoding='utf8')
