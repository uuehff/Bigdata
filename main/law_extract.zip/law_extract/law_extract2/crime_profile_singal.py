# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time
from collections import defaultdict,Counter
import pandas as pd

#count = Counter()

def count_item(count,items):
    #items is a string in a certain row
    if not isinstance(items,float):
        items = str(items)
        item_per_row = items.split(' ')
        #print item_per_row
        for ii in item_per_row:
            count[ii.decode('utf8')] +=1
        #print count
        return count

def del_null_key(count):
    #implement this function after itered all the rows and done the count
    x_t ={}
    for i,v in enumerate(count.keys()):
        if len(v)>0:
            index = v
            value = count[v]
            i_c[index] = value
    return x_t

def save_df(df,row_i,count,col_name):

    count_dict = count[count.keys()[row_i]]
    df.loc[row_i,'crime_reason'] = count.keys()[row_i]
    df.loc[row_i,col_name] =str(count_dict)
    return df




def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1876058#2824916
    reason_crime =defaultdict(Counter)
    for start in range(1,1800000,batch_amount):
        count = Counter()
        if start % 1000 == 0:
            print start
            #time.sleep(1)
        # sql = "SELECT uuid,id,party_info FROM judgment WHERE id >= %d LIMIT %d "  %(start,batch_amount)
        sql = "SELECT id,gender,reason,nation FROM tmp_hzj WHERE id = %d "  % start
        #print sql
        cur.execute(sql)
        #print cur.description
        #print 'cur is',cur

        #print '####'
        for row in cur:
            gender =  row[1]
            #print gender
            #print gender #unicode
            reason = row[2]
            #print reason
            #print reason
            reason = reason.split('||')
            nation = row[3]


            for rr in reason:
                key = rr
                vals = count_item(count,gender)


                #nation_count = count_item(nation)
                reason_crime[rr].update(vals)
                #print reason_crime
    return reason_crime


if __name__ =='__main__':
    reason_item = art_select()
    #print reason_item
    test_new_df = pd.DataFrame()
    for nn in range(len(reason_item.keys())):
        test_new_df = save_df(test_new_df,nn,reason_item,'gender')
    save_path = '/home/sherlock/withcopu_dic/law_extract/law_extract2/test_gender_reason.csv'
    test_new_df.to_csv(save_path,header=True,index=False,encoding='utf8')
