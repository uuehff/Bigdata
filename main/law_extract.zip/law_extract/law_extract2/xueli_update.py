# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time
import pdb

edu_list1 = [u'研究生', u'博士', u'博士后', u'硕士']
edu_list2 = [u'大学', u'本科']
edu_list3 = [u'专科', u'中专', u'大专', u'高职', u'高专']
edu_list4 = [u'高中', u'中学', u'初中']
edu_list5 = [u'小学', u'文盲']

def edustr(edu):
    edunew = ''
    if edu in edu_list1:
        edunew = u'研究生及以上文化'
    elif edu in edu_list2:
        edunew = u'本科文化'
    elif edu in edu_list3:
        edunew = u'专科文化'
    elif edu in edu_list4:
        edunew = u'中学文化'
    elif edu in edu_list5:
        edunew = u'小学及以下文化'
    return edunew


def art_select():
    conn = pymysql.connect(db="laws_doc2", user="hzj", password="123456", host="192.168.12.34",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1800000#2824916
    for start in range(1,44765,batch_amount):
        if start % 1000 == 0:
            print start
            time.sleep(1)

        #pdb.set_trace()

        sql = "SELECT uuid,id,edu,new_edu FROM tmp_hzj WHERE id = %d"  % start

        cur.execute(sql)

        for row in cur:
            dbid = row[1]

            edu = row[2]

            if len(edu)>0:
                edu_s_list=[]
                for edu_l in edu.split('||'):
                    edu_s=edustr(edu_l)
                    edu_s_list.append(edu_s)
                edu_ss = '||'.join(edu_s_list)
            else:
                edu_ss=''

            sql = "UPDATE `tmp_hzj` SET new_edu='%s' WHERE id = %d" %(edu_ss,dbid)
            #print sql
            cur.execute(sql)
            conn.commit()

    cur.close()
    conn.close()

art_select()
