# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time



def common_elements(list1, list2):
    """判断两个list中的共同元素"""
    return [element for element in list1 if element in list2]


def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc_new", user="hzj", password="123456", host="192.168.12.34",port = 3306,charset ='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 3000000#2824916
    for start in range(1,10,batch_amount):
        if start % 1000 == 0:
            print start
            time.sleep(1)

        sql = "SELECT uuid,id,trial_request,casedate,trial_reply FROM judgment_new WHERE id = %d"  % start
        #print start

        cur.execute(sql)

        for row in cur:
            uuid = row[0]


            dbid = row[1]

            trial_request = row[2]
            casedate = row[3]

            trial_reply = row[4]

            #print 'trial_request is',trial_request





            # print 'request',trial_request
            # print 'reply',trial_reply
            # print 'together', trial_request + trial_reply

            if  trial_request:
                trial_request_lst =trial_request.split('\n')
                trial_request = trial_request_lst[0]
                if len(trial_request_lst)>1:
                    trial_reply = trial_request_lst[1]

                    trial_together = trial_request + trial_reply
                else:


                    trial_together = trial_request
                #print start

                dft_idx = [] # defendent
                dft_no_idx = []
                qst_idx = [] # question

                plt =[]
                dft =[]
                qst =[]

                trial_lst = trial_together.split('。')#split by '\n' or '。'
                for idx,cnt in enumerate(trial_lst):

                    if ('被告' in cnt and '辩' in cnt) or ('被告' in cnt and '异议' in cnt) :
                        dft_idx.append(idx)

                    if ('未' in cnt or '没' in cnt) :
                        dft_no_idx.append(idx)

                    if ('审理查明' in cnt )  or ('被告' in cnt and '反驳' in cnt):
                        qst_idx.append(idx)

                if len(dft_idx) >0 :
                    # dft_no_idx = common_elements(dft_idx, dft_no_idx)
                    # if len(dft_no_idx)>0:
                    #
                    #     plt = trial_lst[:dft_no_idx[-1]] # change 0 to -1?
                    #     dft = trial_lst[dft_no_idx[-1]]
                    #     qst = trial_lst[min(dft_no_idx[-1]+1,len(trial_lst)):]

                    if len(qst_idx)>0:

                        plt = trial_lst[:dft_idx[0]]
                        dft = trial_lst[dft_idx[0]:qst_idx[0]]
                        qst = trial_lst[qst_idx[0]:]

                    else:

                        plt = trial_lst[:dft_idx[-1]]
                        dft = trial_lst[dft_idx[-1]:]


                else:
                    plt = trial_lst[:]

                # print 'plt',''.join(plt)
                # print '\n'
                # print 'dft',''.join(dft)
                # print '\n'
                # print 'qst',''.join(qst)

                plt_text = ''.join(plt)
                dft_text = ''.join(dft)
                qst_text = ''.join(qst)
                print type(dft_text.encode('utf8'))
                dft_text = dft_text.encode('utf8').replace("\n","")

                # print type(judge_type)
                #
                trial_request = str(trial_request)
                trial_reply = str(trial_reply)
                # print 'org_text',trial_request
                # print '\n'
                # uuid = str(uuid)
                # dbid = str(dbid)
                # judge_type = str(judge_type)



                sql = "INSERT INTO `tmp_hzj` (`uuid`, `id`,`trial_request`,`trial_reply`,`plt_claim`,`dft_rep`,`crs_exm`) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                cur.execute(sql,(uuid,dbid,trial_request,trial_reply,plt_text,dft_text,qst_text))
                conn.commit()






    cur.close()
    conn.close()


art_select()
