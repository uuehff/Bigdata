## Items For Extracting

- [x] Gender,性别
- [x] Nation,民族
- [x] Age,年龄
- [x] Education，文化程度
- [x] Suspect_num，犯罪人员数量
- [x] Birth_day，生日
- [x] Native_place，籍贯

### to do
##### Jul 12
- [x] 根据罪名，对犯罪人员的性别，民族，年龄，文化，是否团伙等进行统计分析，并将结果存入新的sql表:
  - [x] 已完成gender,nation,edu,计数。
  - [ ] 年龄update: 根据casedate算
  - [ ] 团伙：新建行，if Suspect_num>1,则1，Suspect_num=1,则0，否则为空



#### 3.Jul:

Add info fecthing code from the SQL database to fit the production enviorment.
A test
