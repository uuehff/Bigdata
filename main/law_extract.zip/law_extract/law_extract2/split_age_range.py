# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

from collections import defaultdict,Counter
import pandas as pd

count = Counter()


load_path = '/home/sherlock/withcopu_dic/law_extract/law_extract2/test_multi_col_reason.csv'
test_new_df = pd.read_csv(load_path)
save_path = '/home/sherlock/withcopu_dic/law_extract/law_extract2/test_multi_col_reason2.csv'

def split_age_into(age_str):
    age_dic={}
    age_counter = eval(age_str)
    b12_c = 0
    r1216 = 0
    r1618 = 0
    for ak,av in age_counter.items():
        print type(ak)
        ak = eval(ak)
        if 0<ak <12:
            b12_c += av
            age_dic.update({'b12':b12_c})
        if 12<=ak<16:
            r1216 += av
            age_dic.update({'r1216':r1216})
        if 16<=ak<18:
            r1618 +=av
            age_dic.update({'r1618':r1618})
        if 18<ak<99:
            age_dic.update({str(ak):av})
            #age_dic.up
    return age_dic

for i in range(len(test_new_df)):
    age_str = test_new_df.loc[i,'age']
    new_age_dic = split_age_into(age_str)
    print new_age_dic
    test_new_df.loc[i,'n_age'] = str(new_age_dic)

test_new_df.to_csv(save_path,header=True,index=False,encoding='utf8')
