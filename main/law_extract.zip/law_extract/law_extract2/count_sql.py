# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

from collections import defaultdict,Counter
import pandas as pd

count = Counter()

def count_item(count,items):
    #items is a string in a certain row
    if not isinstance(items,float):
        items = str(items)
        item_per_row = items.split(' ')
        #print item_per_row
        for ii in item_per_row:
            count[ii.decode('utf8')] +=1
        #print count
        return count

def del_null_key(count):
    #implement this function after itered all the rows and done the count
    x_t ={}
    for i,v in enumerate(count.keys()):
        if len(v)>0:
            index = v
            value = count[v]
            i_c[index] = value
    return x_t

def get_all_keys(count_list):
    key_list =[]
    for cc in count_list:
        cc_key = cc.keys()
        key_list.extend(cc_key)

    all_key_list = list(set(key_list))

    return all_key_list



def save_df(df,row_i,key,reason_crime_dic,col_name):


    #count_dict = count[count.keys()[row_i]]
    df.loc[row_i,'crime_reason'] = key
    for idx,cl in enumerate(col_name):
        df.loc[row_i,cl] =str(reason_crime_dic[idx][key])
    return df

def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1800000#2824916
    reason_gender_dic = defaultdict(Counter)
    #reason_dic = {}
    reason_nation_dic = defaultdict(Counter)
    reason_edu_dic = defaultdict(Counter)
    reason_y_dic = defaultdict(Counter)
    reason_adt_dic = defaultdict(Counter)
    reason_crm_team = defaultdict(Counter)
    for start in range(1,total_amount,batch_amount):
        count_g = Counter()
        count_n = Counter()
        count_e = Counter()
        count_y = Counter()
        count_adt = Counter()
        count_cm_tm = Counter()
        if start % 1000 == 0:
            print start
            time.sleep(1)
        # sql = "SELECT uuid,id,party_info FROM judgment WHERE id >= %d LIMIT %d "  %(start,batch_amount)
        sql = "SELECT id,reason,gender,nation,edu,age_year,j_adult,crml_team FROM tmp_hzj WHERE id = %d "  % start
        #print sql
        cur.execute(sql)
        #print cur.description

        #print '####'
        for row in cur:
            #print '000'
            #print row

            #print type(row)


            dbid =  row[0]
            #print uuid
            reason = row[1]
            reason = reason.split('||')
            #print dbid
            gender = row[2]
            nation = row[3]
            edu = row[4]
            age_year = row[5]
            j_adult = row[6]
            crml_team = row[7]

            for rr in reason:

                vals_g = count_item(count_g,gender)
                vals_n = count_item(count_n,nation)
                vals_e = count_item(count_e, edu)
                vals_y = count_item(count_y,age_year)
                vals_adt = count_item(count_adt,j_adult)
                vals_cm_tm = count_item(count_cm_tm,crml_team)
                #vals_s = count_item(count_s, ssp_num)
                reason_gender_dic[rr].update(vals_g)
                reason_nation_dic[rr].update(vals_n)
                reason_edu_dic[rr].update(vals_e)
                reason_y_dic[rr].update(vals_y)
                reason_adt_dic[rr].update(vals_adt)
                reason_crm_team[rr].update(vals_cm_tm)

    return reason_gender_dic,reason_nation_dic,reason_edu_dic,reason_y_dic,\
            reason_adt_dic,reason_crm_team

    cur.close()
    conn.close()

def split_age_into(age_str):
    age_dic={}
    age_counter = eval(age_str)
    for ak,av in age_counter.items():
        if 0<ak <12:
            age_dic['b12'] +=av
        if 12<=ak<16:
            age_dic['12-14'] +=av
        if 16<=ak<18:
            age_dic['18-18'] +=av
        if 18<ak<99:
            age_dic['a18'] +=av
    return age_dic



#this version doesn't work, seems run the gender, nation ,edu,speately will be a good idea beacause it is more robust
if __name__ =='__main__':
    reason_g,reason_n,reason_e,reason_y,reason_a,reason_c = art_select()
    all_key_list = get_all_keys([reason_g,reason_n,reason_e,reason_a,reason_c])
    test_new_df = pd.DataFrame()
    for nn,key in enumerate(all_key_list):
        test_new_df = save_df(test_new_df,nn,key,[reason_g,reason_n,reason_e,reason_y,reason_a,reason_c],['gender','nation','edu','age','adult','criminal_team'])


    save_path = '/home/sherlock/withcopu_dic/law_extract/law_extract2/test_multi_col_reason.csv'
    test_new_df.to_csv(save_path,header=True,index=False,encoding='utf8')
