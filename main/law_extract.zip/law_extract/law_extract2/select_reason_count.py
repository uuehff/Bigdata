# -*- coding: utf-8 -*-
from __future__ import division
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

from collections import defaultdict,Counter
import pandas as pd
import operator

#传入罪名和统计字段，输出统计值
print 'call function'
conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
print 'conn done!'
cur = conn.cursor()

#提取罪名和字段的counter,此处是string格式
nation_amount = {u'汉族':115940,
 u'壮族':1617.88 ,
 u'满族':1068.23,
 u'回族' :981.68,
 u'苗族': 894.01 ,
 u'维吾尔族':839.94,
 u'土家族': 802.81,
 u'彝族':776.23 ,
 u'蒙古族':581.39,
 u'藏族':541.60,
 u'布依族':297.15,
 u'侗族': 296.03 ,
 u'瑶族': 263.74  ,
 u'朝鲜族':192.38,
 u'白族':185.81     ,
 u'哈尼族':143.97 ,
 u'哈萨克族':125.05,
 u'黎族': 124.78 ,
 u'傣族':  115.90,
 u'畲族':    70.96,
 u'僳僳族':    63.49,
 u'仡佬族':    57.94 ,
 u'东乡族':  51.38,
 u'拉祜族':    45.37,
 u'水族':    40.69 ,
 u'佤族':    39.66 ,
 u'纳西族':    30.88,
 u'羌族':    30.61 ,
 u'土族':    24.12 ,
 u'仫佬族':    20.74,
 u'锡伯族':    18.88 ,
 u'柯尔柯孜族':    16.08,
 u'柯尔克孜族':    16.08,
 u'达斡尔族':    13.24 ,
 u'景颇族':    13.21 ,
 u'毛南族':    10.72 ,
 u'撒拉族':    10.45,
 u'布朗族':    9.19 ,
 u'塔吉克族':    4.10,
 u'阿昌族':    3.39 ,
 u'普米族':    3.36 ,
 u'鄂温克族':    3.05,
 u'怒族':    2.88 ,
 u'京族':    2.25 ,
 u'基诺族':    2.09,
 u'德昂族':    1.79 ,
 u'保安族':    1.65 ,
 u'俄罗斯族':    1.56,
 u'裕固族':    1.37 ,
 u'乌孜别克族':    1.24,
 u'门巴族':    0.89 ,
 u'鄂伦春族':    0.82,
 u'独龙族':    0.74 ,
 u'塔塔尔族':    0.49,
 u'赫哲族':    0.45 ,
 u'高山族':    0.45 ,
 u'珞巴族':    0.29}


def extract_reason_stastic(r_name,item_name):
    if isinstance(r_name, str):
        sql = "SELECT %s FROM tmp_prof_hzj WHERE crime_reason = %s" %(item_name,reason_name)
        print sql
        cur.execute(sql)
        rows = cur.fetchone()
        print rows[0]
        print type(rows[0])
        #print query_str
        return rows[0]

        # select_stmt = "SELECT * FROM tmp_prof_hzj WHERE crime_reason = %(reason_name)s"
        # print cur.execute(select_stmt, { 'reason_name': r_name })
        #print query_str
        #return query_str


def counter_kv(query_str,null_in = 0):
    non_sgl=['None','999','99']
    print type(query_str)
    c_dic = eval(query_str)
    if null_in == 1:
        return c_dic
    if null_in == 0:
        notnull_c_dic ={}
        for k,v in c_dic.items():
            print len(k)
            if len(k)>0:
                if k not in non_sgl:
                #print '11'
                    print notnull_c_dic
                    notnull_c_dic.update({k:v})
        print notnull_c_dic
        return notnull_c_dic

def nation_crm_rate(crm_nation_lst,nation_amount):
    crime_rate={}
    for k,v in crm_nation_lst.items():
        if len(k)>0:
            print k
            if k in nation_amount:
                rate = v/(nation_amount[k]*10000)
                crime_rate[k] = rate
    sorted_rate = sorted(crime_rate.items(), key=operator.itemgetter(1),reverse=True)
    return sorted_rate

if __name__ =='__main__':
    reason_name = "'盗窃'"
    item_name = 'nation'

    query_str = extract_reason_stastic(reason_name, item_name)

    sta_dic = counter_kv(query_str)

    for k,v in sta_dic.items():
        print k,v
    print sta_dic

    #if need to caculate the crime_rate based on the nation population

    n_c_rate = nation_crm_rate(sta_dic,nation_amount)
    print type(n_c_rate)
    for i in n_c_rate:
        print i[0],i[1]
