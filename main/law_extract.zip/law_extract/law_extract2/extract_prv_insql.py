# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')

import time
import pandas as pd
import numpy as np
from pyltp import Segmentor
from pyltp import Postagger
#from pyltp import NamedEntityRecognizer
from collections import Counter

segmentor = Segmentor()  # 初始化实例
segmentor.load('/home/sherlock/Documents/ltp_data/cws.model')
#实例化词性工具
postagger = Postagger() # 初始化实例
postagger.load('/home/sherlock/Documents/ltp_data/pos.model')  # 加载模型
#recognizer = NamedEntityRecognizer()
#recognizer.load('/home/sherlock/Documents/ltp_data/ner.model')

def wdseg(inputstr,ret_type):


    words = segmentor.segment(inputstr)  # 分词
    if ret_type == 'str':
        seg_word = ' '.join(words)
    if ret_type == 'lst':
        seg_word = ' '.join(words)
        seg_word = seg_word.split()

    #segmentor.release()  # 释放模型
    return seg_word

def get_pos_list(seg_words):
    #print 'here'
    #print type(seg_words)
    postags = postagger.postag(seg_words)
    #print type(postags)
    pos_list = '\t'.join(postags).split('\t')
    #print type(pos_list)
    return pos_list

def pos_filter(tofilt_pos,seg_words):
    #print 'type segwords',type(seg_words)
    postags = postagger.postag(seg_words)
    pos_list = '\t'.join(postags).split('\t')
    #print pos_list
    #print 'pos list length is ',len(pos_list)
    #print 'segword length is',len(seg_words)
    del_pos_index=set()
    for i,pos in enumerate(pos_list):
        if tofilt_pos in pos:
            #print '11'
            #print i
            del_pos_index.add(i)
            #print seg_words
            #print pos
            #del seg_words[i]

    seg_words =[j for i,j in enumerate(seg_words) if i not in del_pos_index]
    #print len(seg_words)
    #print type(seg_words)
    return seg_words


def find_prv_idx(target_word_str,seg_word_list):
    for idx,ww in enumerate(seg_word_list):
        if target_word_str == ww:
            #print idx
            return idx


def split_by_punc(prv_word_lst):
    dun_count =0
    comma_count=0
    prv_str =''
    for i,w in enumerate(prv_word_lst):
        if comma in w:
            comma_count +=1
        if dunhao in w:
            dun_count +=1

        prv_str = ''.join(prv_word_lst)
        #print prv_str
        if dun_count >=comma_count:
            prv_seg_list = prv_str.split('、')
        elif dun_count < comma_count:
            prv_seg_list = prv_str.split('，')
        elif dun_count == 0 or comma_count ==0:
            prv_seg_list = prv_word_lst
        #for i,v in enumerate(prv_seg_list):
           # if '的' in v:
              #  todelete_words = wdseg(v,'lst')
                #if '的' in todelete_words:
                   # de_index = todelete_words.index('的')
                    #remain_words = todelete_words[de_index:]
                    #prv_seg_list[i] =remain_words


    return ' '.join(prv_seg_list)


def get_prd_index(info_seg_list):
    prd_idx = [idx for idx,v in enumerate(info_seg_list) if v =='。' ]
    return prd_idx

def get_colon_index(info_seg_list):
    colon_idx = [idx for idx,v in enumerate(info_seg_list) if v =='：' ]
    return colon_idx

def get_num_pos_index(pos_list):
    num_pos = [idx for idx,v in enumerate(pos_list) if v =='m']
    return num_pos

def get_aft_colon_split_range(org_list,insert_list):
    new_sort_list = []
    for i in insert_list:
        idx_int = np.searchsorted(org_list, i,side='right')
        if idx_int >=1:
            if i - idx_int<15:
                range_tuple = (org_list[idx_int-1],i)
            else:
                range_tuple = (org_list[idx_int-1],org_list[idx_int-1]+15)
            new_sort_list.append(range_tuple)
    return new_sort_list

def get_bef_prv_till_prd(org_list,insert_idx):
    #new_sort_list=[]
    idx_int = np.searchsorted(org_list,insert_idx,side='right')
    if idx_int > 1:
        new_sort_list = org_list[idx_int-1:idx_int+1]
    else:
        if len(org_list)>3:
            new_sort_list = org_list[1:3]
        else:
            new_sort_list = org_list
    return new_sort_list

comma = '，'
peroid = '。'
dunhao = '、'
colon = '：'


# des_path = '/media/sherlock/new30/law/jun28InfoExtractor/tb_doc_add3.csv'
# law_df = pd.read_csv(des_path)
def extract_prv(courtfind):
#input one row court_find string per time

    if not isinstance(courtfind, float):
        info_words = wdseg(courtfind,'lst')#分词
        #print '###',type(info_words)
        #pos_list = pos_list(info_words)#找出court_find的词性标注列表
        new_info_words = pos_filter('nh', info_words)#去除人名之后的分词
        #print '###',len(new_info_words)
        pos_list = get_pos_list(new_info_words)#找出court_find的词性标注列表
        if find_prv_idx('证据',new_info_words):
            prv_idx = int(find_prv_idx('证据',new_info_words))
            prd_idx = get_prd_index(new_info_words)
            if not isinstance(prd_idx, float):
                prd_prv_range = get_bef_prv_till_prd(prd_idx,prv_idx)
            else:
                prd_prv_range = get_bef_prv_till_prd(0,prv_idx)
            if len(prd_prv_range) >1:


                if find_prv_idx('有',new_info_words[prd_prv_range[0]:prd_prv_range[1]]):
                    you_idx = int(find_prv_idx('有',new_info_words[prd_prv_range[0]:prd_prv_range[1]]))+ prd_prv_range[0]
                else:
                    you_idx ='none'
                prd_idx = get_prd_index(new_info_words)
                prd_prv_range = get_bef_prv_till_prd(prd_idx,prv_idx)
                #print 'the prd_prv_range',prd_prv_range
                #print 'prv_idx',prv_idx
                #print 'prd_idx is',prd_idx
                if you_idx != 'none':
                    prv_word_lst = new_info_words[you_idx:prv_idx+3]
                else:
                    prv_word_lst = new_info_words[prd_prv_range[0]:prd_prv_range[1]+3]

                #for pp in  prv_word_lst:#print pp
                #如果证据的那句话中有逗号和顿号，则提取这段话里面的内容，调用split_by_punc
                #如果证据的那句话有顿号，且顿号后面是字符。则：
                #提取其后所有冒号的位置，提取其后所有数字或者冒号的位置。形成tuple的列表
                #然后便利list of tuples,调用split_by_punc提取其中的内容
                if comma  in prv_word_lst or peroid in prv_word_lst:
                    #print 'comma in'
                    prv_str = split_by_punc(prv_word_lst)
                    return prv_str
                elif colon in prv_word_lst:
                    #print 'colon in'
                    pos_sgl_lst = pos_list[prv_idx:prv_idx+7]
                    #print pos_sgl_lst
                    if 'm' not in pos_sgl_lst:
                        #print  'number not after'
                        prv_str = split_by_punc(prv_word_lst)
                    elif 'm' in pos_sgl_lst and 'wp' in pos_sgl_lst:
                        #print 'number in '
                        num_idx = pos_sgl_lst.index('m')
                        #print num_idx
                        pp_start_idx = prv_idx + num_idx
                        #print pp_start_idx
                        #print new_info_words[pp_start_idx]
                        aft_num_seg_lst = new_info_words[pp_start_idx:]
                        #print aft_num_seg_lst
                        aft_num_pos_lst = pos_list[pp_start_idx:]
                        aft_num_colon_idx = get_colon_index(aft_num_seg_lst)
                        aft_num_idx = get_num_pos_index(aft_num_pos_lst)
                        #print aft_num_idx
                        #print aft_num_colon_idx
                        new_split_range = get_aft_colon_split_range(aft_num_idx, aft_num_colon_idx)
                        #print new_split_range
                        prv_str = ''

                        for rr in new_split_range:
                            #print 'rrr'
                            #print rr[0]
                            #print rr[1]
                            #print aft_num_seg_lst[rr[0]]
                            #print aft_num_seg_lst[rr[0]:rr[1]]
                            prv_str1=split_by_punc(aft_num_seg_lst[rr[0]:rr[1]])
                            prv_str = prv_str + ' '+ prv_str1
                        #prv_str =''.join(prv_lists)
    #print prv_lists
    #law_df.loc[i,'prv'] =prv_str
                    return prv_str


                    #return 'na'
            else:
                return 'na'
        else:
            return 'na'
if __name__ =='__main__':
    extract_prv(courtfind)
