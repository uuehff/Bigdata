# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time
import pdb

def art_select():
    conn = pymysql.connect(db="laws_doc2", user="hzj", password="123456", host="192.168.12.34",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1800000#2824916
    for start in range(1,44764,batch_amount):
        if start % 1000 == 0:
            print start
            time.sleep(1)

        sql = "SELECT uuid,id,delay_date FROM tmp_hzj_JudgeResult WHERE id = %d"  % start

        cur.execute(sql)

        for row in cur:
            dbid = row[1]
            print type(dbid)

            delay_date = row[2]

            if len(delay_date)>0:
                if_delay = 1
            else:
                if_delay = 0
            #print if_delay

            sql = "UPDATE `tmp_hzj_JudgeResult` SET if_delay=%s WHERE id = %s" %(if_delay,dbid)
            cur.execute(sql)
            conn.commit()

    cur.close()
    conn.close()

art_select()
