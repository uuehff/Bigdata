# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time
import law_info_extract as extr


def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc2", user="hzj", password="123456", host="192.168.12.34",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1800000#2824916
    for start in range(1,44765,batch_amount):
        if start % 1000 == 0:
            print start
            time.sleep(1)

        sql = "SELECT uuid,id,court_find,court_idea_origin,party_info,casedate_origin FROM judgment2 WHERE id = %d"  % start

        cur.execute(sql)

        for row in cur:
            uuid = row[0]

            dbid = row[1]

            court_find = row[2]
            court_idea = row[3]
            party_info = row[4]

            casedate = row[5]
            #print 'court_find',court_find
            #print '##############party_info#######',party_info


            if len(str(row[4]))>4:
                #print '1'
                party_info = row[4].encode('utf8')


                info_words = extr.wdseg(party_info.encode('utf8'),'lst')
                gender = extr.get_gender_edu_nation(extr.agenda_list, info_words,8)
                #print gender
                edu = extr.get_gender_edu_nation(extr.xueli_list, info_words,20)
                nation = extr.get_gender_edu_nation(extr.nation_list, info_words,15)


                birth_str = extr.get_birth(info_words)
                if isinstance(birth_str,str):
                #print type(birth_str)
                    bir_age = birth_str
                    year_age = extr.get_year_age(birth_str,casedate)

                    j_adult = extr.judge_adult(year_age)
                else:
                    bir_age='999'
                    year_age ='999'
                    j_adult ='99'
                #print bir_age
                suspect_number = extr.judge_suspect_number(info_words)
                #print 'suspect_number is',type(suspect_number)
                native_place = extr.get_native_palce(info_words)


                crml_team = extr.judge_sus_team(suspect_number)






                # try:

                sql = "INSERT INTO `tmp_hzj` (`uuid`, `id`,`casedate`,`suspect_num`,`birth_day`,`age_year`,`if_team`,`if_adult`,`party_info`,`edu`,`nation`,`gender`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                cur.execute(sql,(uuid,dbid,casedate,suspect_number,bir_age,year_age,crml_team,j_adult,party_info,edu,nation,gender))
                conn.commit()

                # except:
                #     sql = "INSERT INTO `tmp_hzj` (`uuid`, `id`,`casedate`,`suspect_num`,`birth_day`,`age_year`,`crml_team`,`j_adult`,`party_info`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                #     cur.execute(sql,(uuid,dbid,casedate,suspect_number,bir_age,year_age,crml_team,j_adult,party_info))
                #     conn.commit()




    #res = [dict(record) for record in cur]
    cur.close()
    conn.close()


art_select()
