# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

from collections import defaultdict,Counter
import pandas as pd

path = '/home/sherlock/withcopu_dic/law_extract/law_extract2/test_multi_col_reason2.csv'
prf_df = pd.read_csv(path)

print 'call function'
conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
print 'conn done!'
cur = conn.cursor()
for i in range(len(prf_df)):
    print i



    reason = prf_df.loc[i,'crime_reason']
    gender = prf_df.loc[i,'gender']
    nation = prf_df.loc[i,'nation']
    edu = prf_df.loc[i,'edu']
    age = prf_df.loc[i,'n_age']
    adult = prf_df.loc[i,'adult']
    criminal_team = prf_df.loc[i,'criminal_team']

    sql = "INSERT INTO `tmp_prof_hzj` (`crime_reason`, `gender`,`nation`,`edu`,`age_year`,`adult`,`crm_tm`) VALUES (%s,%s,%s,%s,%s,%s,%s)"
    cur.execute(sql,(reason,gender,nation,edu,age,adult,criminal_team))
    conn.commit()


cur.close()
conn.close()
