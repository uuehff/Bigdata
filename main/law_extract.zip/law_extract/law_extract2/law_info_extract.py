# -*- coding: utf-8 -*-

import pandas as  pd
import numpy as np
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import time
from pyltp import Segmentor
from pyltp import Postagger
from pyltp import NamedEntityRecognizer
import re
from collections import Counter
from dateutil import parser

segmentor = Segmentor()  # 初始化实例
segmentor.load('/media/sherlock/new30/ltp_data/cws.model')
#实例化词性工具
postagger = Postagger() # 初始化实例
postagger.load('/media/sherlock/new30/ltp_data/pos.model')  # 加载模型
# recognizer = NamedEntityRecognizer()
# recognizer.load('/home/sherlock/Documents/ltp_data/ner.model')

def wdseg(inputstr,ret_type):


    words = segmentor.segment(inputstr)  # 分词
    if ret_type == 'str':
        seg_word = ' '.join(words)
    if ret_type == 'lst':
        seg_word = ' '.join(words)
        seg_word = seg_word.split()

    #segmentor.release()  # 释放模型
    return seg_word

def deleCnbiaodian(line):
    #替换中文标点
    line = line.decode('utf8')
    string = re.sub("[\s+\.\!\/_,$%^*(+\"\']+|[+——！，。？、~@#￥%……&*（）]+".decode("utf8"), "".decode("utf8"),line)
    #regex = re.compile(ur"[，, 。、；！：（）“”《》？_]")
    return string



nation = u'汉族、蒙古族、回族、藏族、维吾尔族、苗族、彝族、壮族、布依族、朝鲜族、满族、侗族、瑶族、白族、土家族、哈尼族、哈萨克族、傣族、黎族、僳僳族、佤族、畲族、高山族、拉祜族、水族、东乡族、纳西族、景颇族、柯尔克孜族、土族、达斡尔族、仫佬族、羌族、布朗族、撒拉族、毛南族、仡佬族、锡伯族、阿昌族、普米族、塔吉克族、怒族、乌孜别克族、俄罗斯族、鄂温克族、德昂族、保安族、裕固族、京族、塔塔尔族、独龙族、鄂伦春族、赫哲族、门巴族、珞巴族、基诺族'
nation_list = nation.split('、')

agenda_list = [u'男',u'女']
xueli_list = [u'文盲',u'小学',u'中学',u'初中',u'高中',u'大学',u'本科',u'硕士',u'研究生',u'博士',u'博士后']


def get_gender_edu_nation(t_item_list,info_seg_list,n):
#This function could match gender,edu,nation in the orging party_info
# 定位被告位置，并根据性别，文化水平，民族字段和被告位置的距离来提取相应的字段

    indices = [indx for indx,x in enumerate(info_seg_list) if x.decode('utf8') in t_item_list]
    dft_idx = [indx for indx,x in enumerate(info_seg_list) if '被告' in x]
    mult_items = ''
    for ii in indices:
        for df in dft_idx:
            if 0 < ii - df < n:
                mult_items = mult_items + info_seg_list[ii] + '||'
                #print mult_items
        #law_df.loc[i,'gender'] = gender
        #print law_df.loc[i,'gender']
    mult_items = mult_items.rstrip('||')
    return mult_items


def get_birth(info_seg_list):


        # dft_idx = int(info_seg_list.index(i))
    dft_idx = [indx for indx,x in enumerate(info_seg_list) if '被告' in x]
        #print '***' + i +str(info_seg_list.index(i))
    #if '年' in i:
        # yr_idx = int(info_seg_list.index(i))
    yr_idx = [indx for indx,x in enumerate(info_seg_list) if '年' in x]
    #if '生' in i:
        # born_str = int(info_seg_list.index(i))
    born_idx = [indx for indx,x in enumerate(info_seg_list) if '生' in x]
    #jul.5 出现2015年因犯 这种字段被识别成生日。年月日后面要么是逗号要么是生，xx年，XX年YY月

    try:
        new_yy_idx = []
        for yy in yr_idx:
            for dd in dft_idx:
                if  0< yy - dd <10:
                    #print yy
                    new_yy_idx.append(yy)
            # for bb in born_idx:
            #     if 0< bb -yy<5:
            #         print yy
            #         new_yy_idx.append(yy)
        new_yr_idx = list(set(new_yy_idx))
        new_yr_idx.sort()#new_yr_idx = new_yr_idx.sort() is wrong
        new_bir_idx = []
        for yi in new_yr_idx:
            if '，' in info_seg_list[yi+1] or '。' in info_seg_list[yi+1]:
                new_bir_idx.append((yi,yi+1))
            elif '月' in info_seg_list[yi+1]:
                if '，' in info_seg_list[yi+2] or '。' in info_seg_list[yi+2]:
                    new_bir_idx.append((yi,yi+2))
                elif '日' in info_seg_list[yi+2]:
                    if '，' in info_seg_list[yi+3] or '。' in info_seg_list[yi+3]:
                        new_bir_idx.append((yi,yi+3))
                    elif '生' in info_seg_list[yi+3]:
                        new_bir_idx.append((yi,yi+3))

        birth = ''
        for l in new_bir_idx:

            # if yr_idx[l] - dft_idx[l] <10 or born_idx[l] - yr_idx[l] <5:
                #  birth = ''
            for bt_i in range (l[0],l[1]):
                bt = info_seg_list[bt_i]
                birth = birth+bt
            birth = birth +'||'

        birth = birth.rstrip('||')

        return birth

            # if yr_idx - dft_idx <10 or born_str - yr_idx <5:
            #     birth = ''
            #     for bt_i in  range(yr_idx,yr_idx+3):
            #         bt = info_seg_list[bt_i]
            #         birth = birth + bt
            #
            #     #print birth
            #     return birth
    except:
        pass




def get_native_palce(info_seg_list):
    '''提取籍贯，常见的句式是，籍贯XX市，出生于XX市，生于XX市，XX人，XX市出生
    输入：分词list,
    step1生成postaglist,
    step2找出逗号句号的index，这样可以分出句子，
    step3找出籍贯， 出生，人等关键词的index
    step4把signal_word's index匹配进第一步的句子中
    step5然后找出句子中的NS（地点）
    step6输出 地点组成的string'''
    def postaglist(info_seg_list):
        postag = postagger.postag(info_seg_list)
        postag_list = '\t'.join(postag).split('\t')
        return postag_list

    def comma_prd_index(info_seg_list):
        com_prd_idx = [idx for idx,v in enumerate(info_seg_list) if v=='，'or v =='。' or v==',' or v=='.']
        return com_prd_idx

    def find_deft_loc(info_seg_list):
        dft_index = [idx for idx,dft in enumerate(info_seg_list) if u'被告'in dft]
        return dft_index

    def find_pltf_loc(info_seg_list):
        pltf_index = [idx for idx,pltf in enumerate(info_seg_list) if u'原告' in pltf]
        return pltf_index

    def sgl_word_index(dft_start,info_seg_list):
        #唐山县人民法院会被认为是出生地
        #如果party_info中有原告XX，出生于XX，
        #被告人窦某某，47岁，出生于吉林省蛟河市，户籍所在地蛟河市，现住蛟河市
        jg_singal_words3 = u"籍"
        jg_singal_words2 = u"人"
        jg_singal_words1 = u"生"
        jg_singal_blackwords =u"人民"

        #jg_sgl_word_list = jg_singal_words.split(',')
        sgl_word_idx = [ ]
        #for index, sgl in enumerate(jg_sgl_word_list):
        for wd_idx,ww in enumerate(info_seg_list):
            if jg_singal_words1 in ww:
                sgl_word_idx.append(wd_idx)
        #jg_singal_words2 = u'人'
        #jg_sgl_word_list2 = jg_singal_words2.split()
        #for wd_idx2,ww in enumerate(info_seg_list):
            elif jg_singal_words2 in ww and (not jg_singal_blackwords in ww) :
                if wd_idx < len(info_seg_list):
                    punc_idx = wd_idx
                else:
                    punc_idx = wd_idx + 1
                if info_seg_list[punc_idx] ==',' or info_seg_list[punc_idx]=='.'or info_seg_list[punc_idx]=='，' or info_seg_list[punc_idx]=='。':
                    sgl_word_idx.append(wd_idx)
            elif jg_singal_words3 in ww:
                    sgl_word_idx.append(wd_idx)
        #print 'inti_sgl_word index' ,sgl_word_idx

        ##dft_start = find_deft_loc(info_seg_list)
        sgl_word_start = np.searchsorted(sgl_word_idx,dft_start,'left')
        #add pltf index list, and dft start to insert into the list,
        #if the plft list's length is larger than zero and the dft inserted index is
        # less than the plft length ,    then add the next pltf index to the sgl_word_idx
        pltf_idx = find_pltf_loc(info_seg_list)
        if len(pltf_idx)>0 :
            dft_into_pltf_index = np.searchsorted(pltf_idx,dft_start,'left')
            if dft_into_pltf_index < len(pltf_idx):

                sgl_word_end = pltf_idx[dft_into_pltf_index]
                sgl_word_idx = sgl_word_idx[sgl_word_start:sgl_word_end]
            else:
                sgl_word_idx = sgl_word_idx[sgl_word_start:]

        else:

            sgl_word_idx = sgl_word_idx[sgl_word_start:]
        if len(sgl_word_idx)>0:
            sgl_word_idx = sgl_word_idx[0]
        #print info_seg_list[sgl_word_idx]
        return sgl_word_idx

    def sgl_range(sgl_word_index,comma_prd_index):
        sgl_range=[]
        for sg in sgl_word_index:
            start = np.searchsorted(comma_prd_index,sg,'left')
            #print start
            #print len(comma_prd_index)
            if start >0:
                start_range= comma_prd_index[start-1]
                if start <len(comma_prd_index)-1:
                    end_range = comma_prd_index[start]
                else:
                    end_range = comma_prd_index[-1]
                #print 'start_range is' , start_range
                #print 'end_range is',end_range
    #if start == 0:
       # start_range = 0
        #end_range = com_prd_idx[0]
                sgl_range.append((start_range,end_range))
            #print sgl_range
        return sgl_range

    def find_loc(sql_range,postag_list,info_seg_list):
        jg_str = ''
        for i in sgl_range:
            jg_str2 = ''
            if 'ns' in postag_list[i[0]:i[1]]:
                for ix,pp in enumerate(postag_list[i[0]:i[1]]):
                    if pp == 'ns':
                        jg_ns =  info_seg_list[i[0]:i[1]][ix]
                        #print jg_ns
                        jg_str2 = jg_str2+jg_ns
                        #print jg_str2
            jg_str = jg_str + jg_str2 +'||'
        jg_str = jg_str.rstrip('||')
        return jg_str

    postag_list = postaglist(info_seg_list)
    com_prd_index = comma_prd_index(info_seg_list)
    dft_start = find_deft_loc(info_seg_list)
    sgl_idx = []
    for dft in dft_start:

        sgl_index = sgl_word_index(dft, info_seg_list)
        sgl_idx.append(sgl_index)
    sgl_range = sgl_range(sgl_idx, com_prd_index)
    jg_str = find_loc(sgl_range, postag_list, info_seg_list)
    return jg_str.encode('utf8')
    # the native_born_place is still ne


def judge_suspect_number(info_seg_list):

    seg_word_count = Counter(info_seg_list)
    suspect_number = seg_word_count['被告人']
    suspect_number2 = seg_word_count['被告']
    if suspect_number>0:
        return suspect_number
    elif suspect_number2 >0:
        return suspect_number2

def get_year_age(birth_str,casedate):
    time_words = wdseg(birth_str,'lst')
    #print time_words
    year_age=''
    for i in time_words:
        #print '##'
        #print i
        if '年' in i:
            #print '1'
            #print type(i[:4])
            bir_year = i[:4]
            #print bir_year
            #casedate_dt_yr = parser.parse(casedate).year
            #print bir_year



            try:
                #print '11'
                casedate_dt_yr = parser.parse(casedate).year
                #print casedate_dt_yr
                bir_year_int = eval(bir_year)
                #print bir_year_int
                age = casedate_dt_yr - bir_year_int
                #print type(age)
                #print '@@',year_age
                if age>8:
                    year_age = year_age+str(age)+'||'
                #print '***'
                #print 'year_age',year_age

            except:
                pass
    return year_age.rstrip('||')

def judge_sus_team(suspect_number):
    if suspect_number >1:
        team = 1
        return team
    if suspect_number ==1:
        team = 0
        return team

def judge_adult(age):
    if len(age)>0:
        #print age
        j_adult =''
        age = age.split('||')
        for per_age in age:
            #print per_age
            per_age  = int(per_age)
            if per_age >=18:
                j_adult = j_adult +'1' +'||'
            elif 0<per_age <18:
                j_adult = j_adult + '0'+'||'
        j_adult = j_adult.rstrip('||')
        return j_adult


def local_dataframe_process():

    law_path = '/media/sherlock/new30/law/jun28InfoExtractor/tb_doc.csv'
    law_df = pd.read_csv(law_path)
    start = 0
    end = len(law_df)
    step =1

    for i in range(start,end,step):
        info_words = wdseg((law_df.loc[i,'party_info']).encode('utf8'),'lst')
        casedate = law_df.loc[i,'casedate']
        # dft_idx = [indx for indx,x in enumerate(info_words) if '被告' in x]
        law_df.loc[i,'gender'] = get_gender_edu_nation(agenda_list,info_words,8)
        law_df.loc[i,'edu'] = get_gender_edu_nation(xueli_list, info_words,20)
        law_df.loc[i,'nation'] = get_gender_edu_nation(nation_list, info_words,15)
        birth = get_birth(info_words)
        law_df.loc[i,'birth'] = birth
        suspect_number = judge_suspect_number(info_words)
        law_df.loc[i,'suspect_num'] = suspect_number
        law_df.loc[i,'native_place'] = get_native_palce(info_words)
        age = get_year_age(birth, casedate)
        law_df.loc[i,'year_age'] = age
        law_df.loc[i,'team_crmnl'] = judge_sus_team(suspect_number)
        law_df.loc[i,'adult'] = judge_adult(age)

        #print i

    law_df.to_csv('/media/sherlock/new30/law/jun28InfoExtractor/tb_doc_add3.csv',header=True,index=False,encoding='utf8')

if __name__ =='__main__':
    local_dataframe_process()
