# -*- coding: utf-8 -*-
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

'''提取二审中的判罚时间，刑期长度，罚金等'''

# encoding:utf-8

import re
import util_n
import json
import unicodedata as ud

CN_NUM = {
    u'〇' : 0,
    u'１': 1,
    u'-': 1,
    u'一' : 1,
    u'二' : 2,
    u'三' : 3,
    u'四' : 4,
    u'五' : 5,
    u'六' : 6,
    u'七' : 7,
    u'八' : 8,
    u'九' : 9,

    u'零' : 0,
    u'壹' : 1,
    u'贰' : 2,
    u'叁' : 3,
    u'参' : 3,
    u'肆' : 4,
    u'伍' : 5,
    u'陆' : 6,
    u'柒' : 7,
    u'捌' : 8,
    u'玖' : 9,

    u'貮' : 2,
    u'两' : 2
    }
CN_UNIT = {
    u'十' : 10,
    u'拾' : 10,
    u'百' : 100,
    u'佰' : 100,
    u'千' : 1000,
    u'干' : 1000,
    u'仟' : 1000,
    u'仠' : 1000,
    u'万' : 10000,
    u'萬' : 10000,
    u'亿' : 100000000,
    u'億' : 100000000,
    u'兆' : 1000000000000,
    u'年' : 12,
    u'月' : 1,
    }

def cn2dig(cn):
    lcn = list(cn)
    unit = 0 #当前的单位
    ldig = []#临时数组
    other = []
    while lcn:
        cndig = lcn.pop()
        if CN_UNIT.has_key(cndig):
            unit = CN_UNIT.get(cndig)
            if unit==10000:
                ldig.append('w')    #标示万位
                unit = 1
            elif unit==100000000:
                ldig.append('y')    #标示亿位
                unit = 1
            elif unit==1000000000000:#标示兆位
                ldig.append('z')
                unit = 1
            elif unit==12:
                ldig.append('n')
                unit =1
            continue
        elif CN_NUM.has_key(cndig):
            dig = CN_NUM.get(cndig)
            if unit:
                dig = dig*unit
                unit = 0
            ldig.append(dig)
        else:
            other.append(cndig)
    if unit==10:    #处理10-19的数字
        ldig.append(10)
    #print ldig #uncomment this line to watch the middle var.
    ret = 0
    tmp = 0
    while ldig:
        x = ldig.pop()
        if x=='w':
            tmp *= 10000
            ret += tmp
            tmp=0
        elif x=='y':
            tmp *= 100000000
            ret += tmp
            tmp=0
        elif x=='z':
            tmp *= 1000000000000
            ret += tmp
            tmp=0
        elif x=='n':
            tmp *= 12
            ret += tmp
            tmp=0
        else:
            tmp += x
    ret += tmp
    return ret

def to_list(line):
    list_new = []
    if line!='' and line!='None':
        if '||' in line:
            o_list = line.split('||')
            for i in o_list:
                if i!='':
                    list_new.append(i)
        else:
            list_new.append(line)
    return list_new

def punishcate(judge_result):
    control_result = re.search(u'(拘役)', judge_result)
    lock_result = re.search(u'(管制)', judge_result)
    punish_date_result = re.search(u'(有期徒刑|徒刑)', judge_result)
    unlimited_date_result = re.search(u'(无期徒刑)', judge_result)
    death_result = re.search(u'(死刑)', judge_result)
    if death_result:
        punish_cate = u'死刑'
    elif unlimited_date_result:
        punish_cate = u'无期徒刑'
    elif punish_date_result:
        punish_cate = u'有期徒刑'
    elif control_result:
        punish_cate = u'拘役'
    elif lock_result:
        punish_cate = u'管制'
    else:
        punish_cate = ''
    return punish_cate

def punishdate(judge_result):
    punish_date = ''
    punish_date_search = re.search(u'(?<=有期徒刑)\d+(?:年|个月)|((?<=有期徒刑)[\u4e00-\u9fa5]{1,6}(?:年|个月))', judge_result.replace('\n',''))
    if punish_date_search:
        punish_date = str(util_n.as_date_date(punish_date_search.group(0)))
        if re.search(r'\d', punish_date_search.group(0)) and u'年' in punish_date_search.group(0):
            num = filter(str.isdigit, punish_date_search.group(0).encode('gbk'))
            punish_date = str(int(num) * 12)
        elif re.search(r'\d', punish_date_search.group(0)) and u'个月' in punish_date_search.group(0):
            num = filter(str.isdigit, punish_date_search.group(0).encode('gbk'))
            punish_date = str(int(num))
        elif u'半年' in punish_date_search.group(0):
            punish_date = str(6)
        elif u'年十个月' in punish_date_search.group(0):
            punish_date = str(10)
        elif u'年十年' in punish_date_search.group(0):
            punish_date = str(120)
    return punish_date

def delaydate(judge_result):
    delay_date = ''
    delay_date_search = re.search(u'((?<=缓刑)\d+(?:年|个月))|((?<=缓刑)[\u4e00-\u9fa5]{1,7}?(?:年|个月))',
                                  judge_result.replace('\n', ''))
    if delay_date_search:
        delay_date = str(util_n.as_date_delay(delay_date_search.group(0)))
        if re.search(r'\d', delay_date_search.group(0)) and u'年' in delay_date_search.group(0):
            num = filter(str.isdigit, delay_date_search.group(0).encode('gbk'))
            delay_date = str(int(num) * 12)
        elif re.search(r'\d', delay_date_search.group(0)) and u'个月' in delay_date_search.group(0):
            num = filter(str.isdigit, delay_date_search.group(0).encode('gbk'))
            delay_date = str(int(num))
        elif u'半年' in delay_date_search.group(0):
            delay_date = str(6)
    return delay_date
# 拘役
def controldate(judge_result):
    control_date = ''
    control_date_search = re.search(u'((?<=拘役)\d+(?:月|年))|((?<=拘役)[\u4e00-\u9fa5]{1,3}?(?:月|年))',judge_result.replace('\n', ''))
    if control_date_search:
        control_date=util_n.as_date_delay(control_date_search.group(0))
        if re.search(r'\d', control_date_search.group(0)) and u'个月' in control_date_search.group(0):
            num = filter(str.isdigit, control_date_search.group(0).encode('gbk'))
            control_date = str(int(num))
        elif u'一个半月' in control_date_search.group(0):
            control_date = str(1.5)
        elif u'二个半月' in control_date_search.group(0):
            control_date = str(2.5)
        elif u'三个半月' in control_date_search.group(0):
            control_date = str(3.5)
        elif u'四个半月' in control_date_search.group(0):
            control_date = str(4.5)
        elif u'五个半月' in control_date_search.group(0):
            control_date = str(5.5)
    return control_date
# 管制
def lockdate(judge_result):
    lock_date = ''
    lock_date_search = re.search(u'((?<=管制)\d+(?:年|个月))|((?<=管制)[\u4e00-\u9fa5]{1,5}?(?:年|个月))',judge_result.replace('\n', ''))
    if lock_date_search:
        lock_date = util_n.as_date_delay(lock_date_search.group(0))
        if re.search(r'\d', lock_date_search.group(0)) and u'个月' in lock_date_search.group(0):
            num = filter(str.isdigit, lock_date_search.group(0).encode('gbk'))
            lock_date = str(int(num))
        elif re.search(r'\d', lock_date_search.group(0)) and u'年' in lock_date_search.group(0):
            num = filter(str.isdigit, lock_date_search.group(0).encode('gbk'))
            lock_date = str(int(num))
        elif u'半年' in lock_date_search.group(0):
            lock_date = str(6)
    return lock_date
# 剥夺政治权利时长
def rightdate(judge_result):
    right_date = ''
    right_date_search = re.search(u'((?<=剥夺政治权利)\d+(?:年|个月))|((?<=剥夺政治权利)[\u4e00-\u9fa5]{1,5}?(?:年|个月))', judge_result)
    if right_date_search:
        right_date = str(util_n.as_date_date(right_date_search.group(0)))
        # print judge_result.encode('GB18030')
        # print right_date_search.group(0),right_date
    if u'剥夺政治权利' in judge_result and u'终身' in judge_result:
        right_date = u'终身'
    return right_date


from pyltp import Segmentor
segmentor = Segmentor()  # 初始化实例
segmentor.load('/media/sherlock/new30/ltp_data/cws.model' )#change to loacal model path

def wdseg(inputstr,ret_type):
    inputstr = inputstr.encode('utf8')
    words = segmentor.segment(inputstr)  # 分词
    if ret_type == 'str':
        seg_word = ' '.join(words)
    if ret_type == 'lst':
        seg_word = '\t'.join(words)
        seg_word = seg_word.decode('utf8')
        seg_word = seg_word.split('\t')

    #segmentor.release()  # 释放模型
    return seg_word





def punish_money(judge_result):
    punishmoney=''
    #print type(judge_result)
    judge_result_list = judge_result.split('，')
    #print 'splitted'
    #print type(judge_result_list)
    for jj in judge_result_list:
        #print jj
        if u'罚金' in jj and u'元' in jj:
            #print jj
            tmp_money = cn2dig(unicode(jj))
            #print tmp_money
            #print type(tmp_money)
            if tmp_money>0:
                #print 'add'

                punishmoney = punishmoney+str(tmp_money)+'||'
                #print punishmoney
    #print punishmoney
    return punishmoney


def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc2", user="hzj", password="123456", host="192.168.12.34",port = 3306,charset ='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 50000#2824916
    for start in range(1,total_amount,batch_amount):
        if start % 1000 == 0:
            print start
            #time.sleep(1)

        sql = "SELECT uuid,id,judge_result_origin FROM judgment2 WHERE id = %d"  % start
        #print start

        cur.execute(sql)

        for row in cur:

            uuid = str(row[0])
            #print type(uuid)

            dbid = str(row[1])



            #judge_result = str(row[2])
            #print judge_result

            punish_cate = ''       # 刑事判决类型（拘役或管制、有期徒刑、无期徒刑、死刑）
            punish_date = ''       # 有期徒刑期（月）
            delay_date = ''        # 缓刑期（月）
            punishmoney = ''      # 罚金
            crime_reason = ''      # 案由 list
            control_date=''        # 拘役时间
            lock_date=''           # 管制时间
            right_date=''          #剥夺政治权利时长
            if_right = 0           #是否剥夺政治权利
            # 案由

            # print crime_reason
            try:
                judge_result = util_n.as_text(row[2])
            except ValueError:
                judge_result = ''
            # punish = re.split(u'\n', i[5])
            if judge_result is not None and len(judge_result):
                # 有期徒刑类型
                punish_cate = punishcate(judge_result)
                punish_cate = str(punish_cate)
                #print type(punish_cate)
                # 有期徒刑期
                punish_date = punishdate(judge_result)
                #print type(punish_date)
                # 缓刑期
                delay_date = delaydate(judge_result)
                #print type(delay_date)
                # 拘役时长
                control_date = controldate(judge_result)
                #print type(control_date)
                # 管制时长
                lock_date = lockdate(judge_result)
                #print type(lock_date)

                punishmoney = punish_money(judge_result)
                #print type(punishmoney)
                # 剥夺政治权利时长
                right_date = rightdate(judge_result)
                # 是否剥夺政治权利
                if right_date:

                    if_right=1

                right_date = str(right_date)

                #print type(right_date)



                sql = "INSERT INTO `tmp_hzj_JudgeResult` (`uuid`, `id`,`judge_result`,`punish_cate`,`punish_date`,`delay_date`,`control_date`,`lock_date`,`right_date`,`punish_money`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                cur.execute(sql,(uuid,dbid,judge_result,punish_cate,punish_date,delay_date,control_date,lock_date,right_date,punishmoney))
                conn.commit()

    cur.close()
    conn.close()

art_select()
