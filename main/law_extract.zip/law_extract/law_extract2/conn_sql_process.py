# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

import law_info_extract as extr
import extract_prv_insql as getprv

def get_birth(info_seg_list):
    for i in info_seg_list:
        if '被告' in i:

            dft_idx = int(info_seg_list.index(i))
            #print '***' + i +str(info_seg_list.index(i))
        if '年' in i:
            yr_idx = int(info_seg_list.index(i))
        if '生' in i:
            born_str = int(info_seg_list.index(i))
            try:
                if yr_idx - dft_idx <10 or born_str - yr_idx <5:
                    birth = ''
                    for bt_i in  range(yr_idx,yr_idx+3):
                        bt = info_seg_list[bt_i]
                        birth = birth + bt

                    #print birth
                    return birth
            except:
                pass




def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 1800000#2824916
    for start in range(1876102,2824819,batch_amount):
        if start % 1000 == 0:
            print start
            time.sleep(1)
        #sql = "SELECT province FROM tmp_raolu WHERE id >= %d LIMIT %d "  %(start,batch_amount)
        #cur.execute(sql)
        #print cur.description
        #for row in cur:
            #province = row[0]
            #print province
        #print province
        sql = "SELECT uuid,id,casedate,type,party_info,court_find,reason FROM judg2 WHERE id = %d "  % start
        #print sql
        cur.execute(sql)
        #print cur.description

        #print '####'
        for row in cur:
            #print '000'
            #print row

            #print type(row)


            uuid =  row[0]
            #print uuid
            dbid = row[1]
            #print dbid
            casedate = row[2]
            type3 = row[3]
            reason = row[6]
            #print row[4]
            #print type((row[4]))
            #print len(str(row[4]))
            #court_find = row[5].encode('utf8')
            if len(str(row[4]))>4:
                #print '1'
                party_info = row[4].encode('utf8')


            #print party_info
            #print type(party_info)

                #print '11'
            #print party_info

                info_words = extr.wdseg(party_info.encode('utf8'),'lst')
                gender = extr.get_gender_edu_nation(extr.agenda_list, info_words,8)
                #print gender
                edu = extr.get_gender_edu_nation(extr.xueli_list, info_words,20)
                nation = extr.get_gender_edu_nation(extr.nation_list, info_words,15)
                birth_str = extr.get_birth(info_words)
                if isinstance(birth_str,str):
                #print type(birth_str)
                    bir_age = birth_str
                    year_age = extr.get_year_age(birth_str,casedate)
                    #print 'year_age',len(year_age)
                    j_adult = extr.judge_adult(year_age)
                else:
                    bir_age='999'
                    year_age ='999'
                    j_adult ='99'
                #print bir_age
                suspect_number = extr.judge_suspect_number(info_words)
                #print 'suspect_number is',type(suspect_number)

                native_place = extr.get_native_palce(info_words)
                #year_age = extr.get_year_age(birth_str,casedate)
                crml_team = extr.judge_sus_team(suspect_number)


                #j_adult = extr.judge_adult(year_age)
                #print'year age type is', type(year_age)
                if isinstance(row[5],str):
                    court_find = row[5].encode('utf8')
                    try:
                        prvs = getprv.extract_prv(court_find).encode('utf8')
                        #print 'the lenght of prv is',len(prvs)
                        if prvs:
                            if len(prvs)>5000:
                                prvs = prvs[:5000]
                    except:
                        prvs ='na'


                try:

                    sql = "INSERT INTO `tmp_hzj` (`uuid`, `id`,`casedate`,`type`,`reason`,`gender`,`nation`,`edu`,`suspect_num`,`birth_day`,`native_place`,`age_year`,`crml_team`,`j_adult`,`prvs`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                    cur.execute(sql,(uuid,dbid,casedate,type3,reason,gender,nation,edu,suspect_number,bir_age,native_place,year_age,crml_team,j_adult,prvs))
                    conn.commit()

                except:
                    sql = "INSERT INTO `tmp_hzj` (`uuid`, `id`,`casedate`,`type`,`reason`,`gender`,`nation`,`edu`,`suspect_num`,`birth_day`,`native_place`,`age_year`,`crml_team`,`j_adult`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                    cur.execute(sql,(uuid,dbid,casedate,type3,reason,gender,nation,edu,suspect_number,bir_age,native_place,year_age,crml_team,j_adult))
                    conn.commit()

                #for ww in info_words: print ww

            #print result[1]



    #res = [dict(record) for record in cur]
    cur.close()
    conn.close()



art_select()
