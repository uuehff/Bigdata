# -*- coding: utf-8 -*-

import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pymysql
import time

import law_info_extract as extr
import extract_prv_insql as getprv

'''select from birth_year, update the age_year and j_adult'''

def art_select():
    print 'call function'
    conn = pymysql.connect(db="laws_doc", user="hzj", password="123456", host="192.168.10.24",port = 3306,charset='utf8mb4')
    print 'conn done!'
    cur = conn.cursor()
    batch_amount = 1
    total_amount = 2900000#2824916
    for start in range(1,total_amount,batch_amount):
        if start % 1000 == 0:
            print start
            time.sleep(1)
        #sql = "SELECT province FROM tmp_raolu WHERE id >= %d LIMIT %d "  %(start,batch_amount)
        #cur.execute(sql)
        #print cur.description
        #for row in cur:
            #province = row[0]
            #print province
        #print province
        sql = "SELECT id,birth_day,casedate FROM tmp_hzj WHERE id = %d "  % start
        #print sql
        cur.execute(sql)
        #print cur.description

        #print '####'
        for row in cur:
            #print '000'
            #print row

            #print type(row)


            dbid =  row[0]
            # print dbid
            # print type(dbid)
            #print uuid
            birth_year = row[1].encode('utf8')
            casedate = row[2]
            # print birth_year
            # print casedate
            #
            # print len(birth_year)


            if len(birth_year)>0:
                #print '11'
            #print type(birth_str)
                #bir_age = birth_year
                #print birth_year
                year_age = extr.get_year_age(birth_year,casedate)
                #print 'year_age',len(year_age)
                j_adult = extr.judge_adult(year_age)
                #print year_age
                #print type(year_age)
            else:
                bir_age='999'
                year_age ='999'
                j_adult ='99'


            sql = "UPDATE  tmp_hzj SET age_year= %(age)s, j_adult = %(adult)s WHERE `id`=%(id)s"
            #print sql
            cur.execute(sql ,{'age':year_age,'adult':j_adult,'id':start})


            conn.commit()

                # except:
                #     sql = "INSERT INTO `tmp_hzj` ( `id`,`casedate`,`type`,`reason`,`gender`,`nation`,`edu`,`suspect_num`,`birth_day`,`native_place`,`age_year`,`crml_team`,`j_adult`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
                #     cur.execute(sql,(uuid,dbid,casedate,type3,reason,gender,nation,edu,suspect_number,bir_age,native_place,year_age,crml_team,j_adult))
                #     conn.commit()

                #for ww in info_words: print ww

            #print result[1]



    #res = [dict(record) for record in cur]
    cur.close()
    conn.close()



art_select()
